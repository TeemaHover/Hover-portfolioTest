particlesJS.load('particle-container', 'assets/js/particle-config.json', function() {});
particlesJS.load('particle-mobile-container', 'assets/js/particle-mobile-config.json', function() {});
